#!/bin/sh
cp -r ../../XTA_L64 ./